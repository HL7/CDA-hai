This readme is included in a zip file which packages the publication release for:
  HL7 Implementation Guide for CDA� Release 2:
  NHSN Healthcare Associated Infection (HAI) Reports
  Release 4, STU 2.1 � US Realm
  July 2023
  STU Unballoted Update

The package was prepared by Lantana Consulting Group, LLC.

Contents of the package:
========================

_readme.txt                         This file

                                 -- the STU -- 
                        
CDAR2_IG_HAIRPT_R4_STU2.1_V1_Introductory_Material.docx      NHSN Healthcare Associated Infection (HAI) Report Release 4�US Realm, STU 2.1, Volume 1 in Microsoft Word format
CDAR2_IG_HAIRPT_R4_STU2.1_V2_Templates_and_Supporting.docx   NHSN Healthcare Associated Infection (HAI) Report Release 4�US Realm, STU 2.1, Volume 2 in Microsoft Word format
CDAR2_IG_HAIRPT_R4_STU2.1_V3_AU_AR_Appendix.docx             NHSN Healthcare Associated Infection (HAI) Report Release 4�US Realm, STU 2.1, Volume 3 in Microsoft Word format
CDAR2_IG_HAIRPT_R4_STU2.1_V4_HV_Appendix.docx                NHSN Healthcare Associated Infection (HAI) Report Release 4�US Realm, STU 2.1, Volume 4 in Microsoft Word format

                                 -- Sample files: --
Sample files are housed on the HL7 GitHub site:
	GitHub link: https://github.com/HL7/CDA-hai/tree/master/CDAR2_IG_HAIRPT_R4_STU2.1_XML_and_Support_Files
                                 
                                 -- Single Person (numerator) reports --
                        
xml/sample/aro-num.xml                             Antimicrobial Resistance Option numerator sample file
xml/sample/bsi-num.xml                             Bloodstream Infection numerator sample file
xml/sample/clip-num.xml                            Central line insertion practice numerator sample file
xml/sample/eoid-num.xml                            Evidence of Infection - Dialysis numerator sample file
xml/sample/lio-num.xml                             Laboratory Identified Organism numerator sample file
xml/sample/los-denom_location1.xml		   Late Onset Sepsis denominator sample file
xml/sample/los-denom_location2.xml		   Late Onset Sepsis denominator sample file
xml/sample/los-num.xml				   Late Onset Sepsis/Meningitis Event (LOS) Report numerator sample file
xml/sample/opc_proc-denom.xml			   Outpatient procedure denominiator sample file
xml/sample/opc_sdom-num.xml
xml/sample/opc_ssi-num.xml
xml/sample/proc-denom.xml                          Procedure denominator sample file
xml/sample/ssi-num.xml                             Surgical Site Infection numerator sample file
xml/sample/uti-num.xml                             Urinary tract Infection numerator sample file
xml/sample/vae-num.xml                             Ventilator-associated infection numerator sample file

                                 -- Summary (denominator) reports --
                                 
xml/sample/pop_sum-denom.xml                       Population summary denominator sample file
xml/sample/pop_sum-denom-ARO-INPATIENT.xml         Population summary denominator sample file for Antimicrobial Resistance Option (inpatient)
xml/sample/pop_sum-denom-ARO-OUTPATIENT.xml        Population summary denominator sample file for Antimicrobial Resistance Option (outpatient)
xml/sample/pop_sum-denom-AUP.xml                   Population summary denominator sample file for Antimicrobial Usage and Resistance
xml/sample/pop_sum-denom-NICU.xml                  Population summary denominator sample file for NICU
xml/sample/pop_sum-denom-OPC-SDOM		   Population summary denominator sample file for OPC Same Day Outcome Measures
xml/sample/pop_sum-denom-POM.xml                   Population summary denominator sample file for Prevention Process and Outcome Measures
xml/sample/pop_sum-denom-POM-FACWIDEIN.xml         Population summary denominator sample file for Prevention Process and Outcome Measures
xml/sample/pop_sum-denom-POM-FACWIDEOUT.xml        Population summary denominator sample file for Prevention Process and Outcome Measures
xml/sample/pop_sum-denom-SCA.xml                   Population summary denominator sample file for Specialty Care Areas
xml/sample/pop_sum-denom-VAT.xml                   Population summary denominator sample file for Chronic Hemodialysis Patients
xml/sample/pop_sum-denom-HV.xml                    Population summary denominator sample file for Hevovigilance Reporting
xml/sample/pop_sum-denom-HP-FLU.xml                Population summary denominator sample file for Influenza Vaccination Summary

                                 -- NHSN Logo --
                                 
xml/sample/nhsnlogo_small.gif                      NHSN Logo
                                
                                -- Support files --                      
                
XML and Related files (Schematron, sample, html, stylesheet) are housed on the HL7 GitHub:
	https://github.com/HL7/CDA-hai/tree/master/CDAR2_IG_HAIRPT_R4_STU2.1_XML_and_Support_Files
	
The latest CDA Schema is located on the HL7 GitHub site:
	https://github.com/HL7/cda-core-2.0/tree/master/schema/extensions 

Direct questions about the ballot to the HL7 Structured Documents Working Group.
July 2023