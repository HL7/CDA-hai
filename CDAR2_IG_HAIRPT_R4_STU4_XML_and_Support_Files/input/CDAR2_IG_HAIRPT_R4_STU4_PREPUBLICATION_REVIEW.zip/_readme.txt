This readme is included in a zip file which packages the publication package for:
  HL7 Implementation Guide for CDA� Release 2:
  NHSN Healthcare Associated Infection (HAI) Reports
  Release 4, STU 4 � US Realm
  
  4.4 July 2025
  STU Publication

The package was prepared by Lantana Consulting Group, Inc.

NOTE: The date specified in this README file is the Lantana Consulting Group delivery date for this file package. 
Dates on the Implementation Guide cover page and footer will change when the Implementation Guide is balloted or published through HL7. 

Contents of the package:
========================
_readme.txt                         This file

--Implementation Guide files--
CDAR2_IG_HAIRPT_R4_STU4_V1_Introductory_Material.docx      NHSN Healthcare Associated Infection (HAI) Report Release 4�US Realm, STU 4, Volume 1 in Microsoft Word format
CDAR2_IG_HAIRPT_R4_STU4_V2_Templates_and_Supporting.docx   NHSN Healthcare Associated Infection (HAI) Report Release 4�US Realm, STU 4, Volume 2 in Microsoft Word format
CDAR2_IG_HAIRPT_R4_STU4_V3_AU_AR_Appendix.docx             NHSN Healthcare Associated Infection (HAI) Report Release 4�US Realm, STU 4, Volume 3 in Microsoft Word format
CDAR2_IG_HAIRPT_R4_STU4_V4_HV_Appendix.docx                NHSN Healthcare Associated Infection (HAI) Report Release 4�US Realm, STU 4, Volume 4 in Microsoft Word format

======================== GitHub ========================

XML and Related files (Schematron, sample, html, stylesheet) are housed on the HL7 GitHub:
	https://github.com/HL7/CDA-hai/tree/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files

                                 -- Sample Files --                                 
                                 -- Single Person (numerator) reports --
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/aro-num.xml                             Antimicrobial Resistance Option numerator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/bsi-num.xml                             Bloodstream Infection numerator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/clip-num.xml                            Central line insertion practice numerator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/eoid-num.xml                            Evidence of Infection - Dialysis numerator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/lio-num.xml                             Laboratory Identified Organism numerator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/los-denom_location1.xml		    Late Onset Sepsis denominator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/los-denom_location2.xml		    Late Onset Sepsis denominator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/los-num.xml			            Late Onset Sepsis/Meningitis Event (LOS) Report numerator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/opc_proc-denom.xml		            Outpatient procedure denominiator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/opc_sdom-num.xml                        Outpatient Procedure Component Same Day Outcome Measure Event sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/opc_ssi-num.xml			    Outpatient Procedure Component Surgical Site Infection Report (SSI) sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/proc-denom.xml                          Procedure denominator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/ssi-num.xml                             Surgical Site Infection numerator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/uti-num.xml                             Urinary tract Infection numerator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/vae-num.xml                             Ventilator-associated infection numerator sample file

                                 -- Summary (denominator) reports --
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom.xml                       Population summary denominator sample file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-ARO-INPATIENT.xml         Population summary denominator sample file for Antimicrobial Resistance Option (inpatient)
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-ARO-OUTPATIENT.xml        Population summary denominator sample file for Antimicrobial Resistance Option (outpatient)
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-AUP.xml                   Population summary denominator sample file for Antimicrobial Usage and Resistance
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-NICU.xml                  Population summary denominator sample file for NICU
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-OPC-SDOM		    Population summary denominator sample file for OPC Same Day Outcome Measures
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-POM.xml                   Population summary denominator sample file for Prevention Process and Outcome Measures
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-POM-FACWIDEIN.xml         Population summary denominator sample file for Prevention Process and Outcome Measures
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-POM-FACWIDEOUT.xml        Population summary denominator sample file for Prevention Process and Outcome Measures
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-SCA.xml                   Population summary denominator sample file for Specialty Care Areas
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-VAT.xml                   Population summary denominator sample file for Chronic Hemodialysis Patients
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-HV.xml                    Population summary denominator sample file for Hevovigilance Reporting
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/pop_sum-denom-HP-FLU.xml                Population summary denominator sample file for Influenza Vaccination Summary

				-- Schematron validation files -�
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/schematron/hai.sch            		            Schematron validation file
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/schematron/hai_voc.xml		                    Associated vocabulary file used in Schematron validation

				-- Transform files -�
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/transform/hai-display.xsl			    Transform sample files into HTML
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/transform/generate-narrative.xsl		    Generate narrative from coded entries

                                 -- NHSN Logo --
https://github.com/HL7/CDA-hai/blob/master/CDAR2_IG_HAIRPT_R4_STU4_XML_and_Support_Files/xml/sample/nhsnlogo_small.gif                      NHSN Logo
                                
                                -- Support files --                      
The latest release of the CDA Schema can be downloaded from GitHub: https://github.com/HL7/cda-core-2.0/tree/master/schema/extensions/SDTC

July 2025